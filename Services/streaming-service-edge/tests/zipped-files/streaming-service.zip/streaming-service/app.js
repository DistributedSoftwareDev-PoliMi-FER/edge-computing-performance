const express = require('express');

const app = express();

app.use('/-/ready', (req, res) => {
	res.status(200).send('1');
});
app.use('/-/healthz', (req, res) => {
	res.status(200).send('1');
});
app.use('/test', (req, res) => {
	res.status(200).send('1');
});

app.listen(9999, () => {
	console.log(`Endless useless listening`);
});

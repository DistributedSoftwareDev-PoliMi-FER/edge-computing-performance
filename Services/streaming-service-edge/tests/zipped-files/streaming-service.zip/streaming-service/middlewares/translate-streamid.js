// Const axios = require('axios');

const Stream = require('../models/stream');

const resolvedKeys = new Map();

module.exports = (req, res, next) => {
	if(resolvedKeys.get(req.params.streamid)) {
		// Get an already resolved streamkey
		req.streamkey = resolvedKeys.get(req.params.streamid);
		next();
	}
	else {
		Stream.findById(req.params.streamid)
			.then((stream) => {
				if(!stream) {
					// No stream found
					return res.sendStatus(404);
				}
				// Stream found
				req.streamkey = stream.streamkey;
				resolvedKeys.set(req.params.streamid, stream.streamkey);
				next();
			})
			.catch((err) => {
				next(err);
			});
	}
};

// 
// // Resolve and save the streamkey
// axios
// .get(`${process.env.API_SERVICE_HOST}/api/stream/${req.params.streamid}`)
// .then(({ data }) => {
// 				// Handle success
// 				req.streamkey = data.user.stream_key;
// 				resolvedKeys.set(req.params.streamid, data.user.stream_key);
// 				next();
// })
// .catch((error) => {
// 				// Handle error
// 				console.log(error);
// 				return res.sendStatus(404);
// });
// 

// NPM import modules
const express = require('express');
const router = express.Router();
const swaggerConf = require('../config/swagger.json');

router.use('/-/ready', (req, res) => {
	res.status(200).send('1');
});
router.use('/-/healthz', (req, res) => {
	res.status(200).send('1');
});
router.use('/documentation/json', (req, res) => {
	res.send(swaggerConf);
});

module.exports = router;
